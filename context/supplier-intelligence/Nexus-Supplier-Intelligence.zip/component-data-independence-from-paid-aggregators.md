---
claim: "Component pricing and BOM validation data does not require a paid aggregator API — free distributor APIs plus a self-hosted cache layer provide equivalent coverage at the usage scale of 1k–50k calls per month"
status: active
date: 2026-04-09
owner: ""
last_reviewed: 2026-04-09
next_review: 2026-07-09
supporting_decisions:
  - "[[decisions/replace-nexar-octopart-with-multi-distributor-api-platform]]"
falsified_by:
  - "DigiKey, Mouser, Arrow, or Element14 introduce per-query fees that make free tier unviable at 1k–50k calls/month"
  - "Distributor APIs fail to return data for >20% of MPNs in a representative BOM sample"
  - "Normalizing responses across 4+ distributor API schemas requires >2 engineer-weeks of ongoing maintenance per quarter"
  - "OEMsecrets API proves unreliable or cost-prohibitive as a fallback for Future Electronics coverage"
tags:
  - strategy
  - component-data
  - vendor-independence
  - api
  - bom
  - ai-platform
---

## Claim

Component pricing and BOM validation data does not require a paid aggregator API (Nexar, Octopart, or equivalent). Free distributor APIs from DigiKey, Mouser, Arrow, and Element14 — combined with a Redis cache layer — provide equivalent distributor coverage and data quality at the 1k–50k API call per month usage scale.

## Rationale

Paid aggregators like Nexar bundle three things: (1) multi-distributor data access, (2) a unified schema, and (3) lifecycle/compliance enrichment. At moderate usage scale, (1) is available for free directly from distributors, and (2) can be solved once with a normalizer. Only (3) — lifecycle status, EOL alerts, RoHS/REACH compliance — has no free equivalent and may justify a targeted paid tool in future.

The current cost pain is caused by Nexar's forced migration from Octopart v4 to a metered enterprise plan, not by an inherent market gap. All six distributor sources used by the legacy system have independent free APIs.

## Evidence gathered (2026-04-09)

- DigiKey Product Information v4: free REST API, OAuth2, covers search, pricing with quantity breaks, substitutions, PCN (Product Change Notifications)
- Mouser API: free, API key required from mouser.com/api-hub, rate-limited per minute and per day — cache is mandatory
- Arrow Pricing & Availability API: free, login + API key, documented at developers.arrow.com
- Element14/Farnell/Newark: free Partner API, single key covers all three regional storefronts, covers 1.3M+ products, "courtesy usage allowance" applies — usage terms need confirmation
- OEMsecrets Part Search API: 140+ distributors including Future Electronics, Avnet, RS; JSON API access by request; pricing model not fully public
- FindChips: no standalone API — enterprise UI integrations only; excluded
- Z2Data: no API available; UI-only; excluded
- InvenTree: open-source self-hosted inventory + BOM management, full REST API, Docker-deployable; optional complement to M3

## Risks to this claim

See [[risks/distributor-api-rate-limit-dependency]] and [[risks/oemsecrets-pricing-opacity]].

The normalizer maintenance burden is the highest-probability falsification path. Distributor APIs change schema without notice. This must be managed with schema validation tests and automated alerts on API response structure changes.

## Relationship to M3

M3 is the system of record for internal part numbers (IPN), manufacturer part numbers (MPN), and approved supplier lists. This claim does not challenge that. The component data service enriches M3 records with live market data — it does not replace M3 as the part master.

See [[decisions/m3-is-system-of-record-for-part-master]].

## Drift signals

Watch for:
- Any distributor in the approved list announcing API monetization or usage caps
- BOM validation hit rate dropping below 80% on production MPNs (indicates API coverage gap)
- Normalizer schema patches being required more than once per quarter per distributor
- OEMsecrets transitioning to a subscription model that changes the cost calculus
- A competitor or peer manufacturer reporting success or failure with this pattern
