---
claim: "Nexar/Octopart API is replaced by a self-hosted multi-distributor component data service built on free distributor APIs, with M3 as the part master and a Redis cache to control query volume"
status: active
date: 2026-04-09
owner: ""
last_reviewed: 2026-04-09
next_review: 2026-07-09
adr_id: "ADR-XXX"
reversibility: medium
supporting_evidence:
  - "Nexar free eval tier capped at 100 matched parts/month — unworkable at 1k–50k call scale"
  - "Octopart API v4 and RESTful wrapper deprecated — forced migration to Nexar paid tiers"
  - "DigiKey, Mouser, Arrow, Element14 all offer free developer APIs covering same distributor set"
  - "OEMsecrets API covers 140+ distributors including Future Electronics as a single fallback"
  - "M3 part master already contains IPN, MPN, and approved supplier lists — real source of truth"
falsified_by:
  - "A free-tier Nexar plan with sufficient quota becomes available"
  - "Distributor APIs (DigiKey, Mouser, Arrow, Element14) introduce per-query fees at our usage scale"
  - "The new platform is shelved and the legacy system requires long-term investment"
related_projects:
  - "[[projects/organizational-ai-platform]]"
related_decisions:
  - "[[decisions/m3-is-system-of-record-for-part-master]]"
related_risks:
  - "[[risks/nexar-api-cost-escalation]]"
  - "[[risks/distributor-api-rate-limit-dependency]]"
related_vendors:
  - "[[vendors/nexar-altium]]"
  - "[[vendors/digikey]]"
  - "[[vendors/mouser]]"
  - "[[vendors/arrow-electronics]]"
  - "[[vendors/element14-farnell-newark]]"
  - "[[vendors/oemsecrets]]"
tags:
  - architecture
  - component-data
  - api
  - bom
  - procurement
  - ai-platform
---

## Decision

Replace Nexar/Octopart as the component pricing and BOM validation data source with a self-hosted **Component Data Service** that fans out to free distributor APIs (DigiKey, Mouser, Arrow, Element14) with OEMsecrets as a fallback aggregator. M3 remains the authoritative part master. A Redis cache layer controls API query volume.

This decision applies to both the legacy production system (as a deferred improvement) and the new organizational AI platform (as foundational infrastructure for BOM analysis and ECN management).

## Context

The legacy production system sources component data from DigiKey, Octopart, Future Electronics, Mouser, Element14, and Arrow via the Nexar/Octopart API. API quota overages triggered this review. Investigation revealed:

- Nexar forced a paid tier upgrade to access features required for BOM validation
- The Octopart API v4 has been deprecated — all users are being migrated to Nexar's GraphQL API with custom enterprise pricing
- The free evaluation plan is capped at 100 matched parts per month, unworkable at 1k–50k calls per month
- All six distributor sources already offer free, documented developer APIs independently
- M3 already contains the internal part master (IPN, MPN, approved supplier mapping) — Nexar was only filling the live pricing/availability gap

The new organizational AI platform is 2–3 months from replacing the legacy system and will include BOM analysis and ECN management as core features. The component data problem must be solved at the platform level, not patched in the legacy system.

## Decision Drivers

- Cost: Nexar pricing is not justifiable at current or projected usage scale
- Vendor lock-in: Forced migration from Octopart v4 to Nexar GraphQL with no pricing transparency
- Architectural fit: A composable, API-first data service aligns with the broader platform strategy
- Data ownership: M3 is the system of record — external APIs should enrich it, not replace it
- Governance: The organizational AI platform requires traceable, auditable component data lineage

## Architecture

```
Internal App / AI Platform
         │
         ▼
┌─────────────────────────────────────────────┐
│         Component Data Service              │
│  ┌──────────┐ ┌─────────────┐ ┌──────────┐ │
│  │  Pricing │ │ BOM         │ │Normalizer│ │
│  │  Cache   │ │ Validator   │ │          │ │
│  │ (Redis)  │ │ (batch/dedup│ │JSON schema│ │
│  │ 24–48h   │ │ by MPN)     │ │per source│ │
│  └──────────┘ └─────────────┘ └──────────┘ │
│         Fallback Router                     │
│  DigiKey → Mouser → Arrow → E14 → OEMsecrets│
└─────────────────────────────────────────────┘
         │                    │
         ▼                    ▼
  Distributor APIs       M3 Part Master
  (free, keyed)         (IPN / MPN / suppliers)
```

### Distributor API inventory

| Distributor | API | Auth | Cost | Notes |
|-------------|-----|------|------|-------|
| DigiKey | Product Information v4 (REST) | OAuth2 + Client ID | Free | Best documented; tiered pricing in response |
| Mouser | Search API (REST) | API key | Free | Rate-limited per minute and per day; caching essential |
| Arrow | Pricing & Availability API | Login + API key | Free | Covers Arrow catalog; separate from Verical |
| Element14 / Farnell / Newark | Product Search API (REST) | Partner key | Free (courtesy allowance) | Single key covers all three regional storefronts |
| OEMsecrets | Part Search API (JSON) | Request-based | Low cost | 140+ distributors including Future Electronics; used as fallback aggregator |
| Future Electronics | None | — | — | Covered via OEMsecrets fallback |

### Cache TTL strategy (deferred — see [[strategy/component-pricing-cache-ttl-strategy]])

TTL design depends on whether pricing is used for real-time quoting vs. BOM cost estimation, and spot buy vs. contract pricing patterns. To be finalized during platform design phase.

### What is explicitly not built

- No Nexar/Octopart dependency at any layer
- No scraping of distributor websites (brittle, ToS risk)
- No BOM.AI or China-market-specific sources (out of scope for current platform)
- No Z2Data or SiliconExpert (no public API; out of scope)
- InvenTree is optional — viable if a REST-accessible internal component registry is needed decoupled from M3's UI

## Consequences

**Positive**
- Eliminates Nexar licensing cost entirely
- Removes single-vendor dependency for component data
- All six current distributor sources remain covered
- Cache layer structurally prevents quota overages from re-occurring
- Component data service becomes reusable infrastructure for BOM analysis and ECN management

**Negative / Trade-offs**
- Engineering effort to build and maintain the normalizer across multiple API schemas
- Distributor APIs may change schema or auth without notice — requires monitoring
- OEMsecrets pricing model is "request-based" and not fully public — needs evaluation before production use
- Mouser API has per-minute and per-day rate limits — cache TTL strategy is non-trivial

## Decision: Legacy system vs. new platform

Given the 2–3 month replacement timeline and "painful but workable" severity of the current quota issue, **do not retrofit the legacy system**. Triage the legacy system with:
1. Temporary quota increase request to Nexar (one email)
2. Application-layer request deduplication (15-minute MPN cooldown)
3. Identify and throttle the highest-volume query paths in logs

Build the Component Data Service as foundational infrastructure in the new platform only.

## Status

Accepted — pending platform design phase kickoff.

## References

- DigiKey API developer portal: https://developer.digikey.com/
- Mouser API hub: https://www.mouser.com/api-hub/
- Arrow API docs: https://developers.arrow.com/api/
- Element14 Partner Portal: https://partner.element14.com/
- OEMsecrets API: https://www.oemsecrets.com/api
- InvenTree (optional registry): https://inventree.org/
- Unified API wrapper (OSS, DigiKey+Mouser+TME): https://github.com/topics/mouser
