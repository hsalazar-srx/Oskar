---
title: "Risk — Distributor API rate limit dependency"
date: 2026-04-09
type: risk
status: active
severity: medium
probability: medium
owner: ""
related_projects:
  - "[[projects/component-data-service]]"
related_decisions:
  - "[[decisions/replace-nexar-octopart-with-multi-distributor-api-platform]]"
tags:
  - risk
  - api
  - component-data
  - infrastructure
---

## Risk

The Component Data Service depends on distributor APIs (especially Mouser and Element14) that impose per-minute and per-day rate limits. Unexpected BOM batch volume or cache failures could exhaust quota, degrading or blocking component data lookups across the platform.

## Impact

BOM analysis and ECN management features become unavailable or return stale data. Procurement workflows are blocked if real-time pricing is required.

## Mitigations

- Redis cache is the primary defense — cache hits generate zero API calls
- Circuit breaker per distributor: if rate-limited (HTTP 429), skip to next in fallback order immediately
- Monitor `X-RateLimit-Remaining` headers on every response; alert at 20% remaining
- Set a daily call budget cap per distributor with alerting before threshold is hit
- BOM batch deduplication: never query the same MPN twice in a single batch run

## Drift signals

- Mouser or Element14 reducing their free tier rate limits without notice
- Cache hit rate dropping below 50% (indicates cache is not absorbing expected volume)
- HTTP 429 errors appearing in production logs
