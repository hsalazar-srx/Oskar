---
title: "Risk — OEMsecrets API pricing opacity"
date: 2026-04-09
type: risk
status: active
severity: medium
probability: low
owner: ""
related_projects:
  - "[[projects/component-data-service]]"
related_decisions:
  - "[[decisions/replace-nexar-octopart-with-multi-distributor-api-platform]]"
tags:
  - risk
  - api
  - vendor
  - component-data
---

## Risk

OEMsecrets API pricing model is described as "request-based" but is not publicly documented. If production usage at the fallback layer proves unexpectedly costly, it reintroduces a cost problem similar to Nexar — particularly for Future Electronics coverage, which has no direct free API alternative.

## Impact

Budget overrun on component data infrastructure. Potential need to re-evaluate Future Electronics data source or negotiate a commercial API arrangement directly with Future.

## Mitigations

- Confirm OEMsecrets pricing model in writing before Phase 2 production commitment
- Use OEMsecrets strictly as a fallback (cache miss + all primary API misses) — not as a primary source
- Set a monthly call budget cap with hard alerting before threshold
- Track OEMsecrets call volume separately in telemetry from day one
- Evaluate TrustedParts API as an alternative fallback if OEMsecrets pricing is unfavorable

## Drift signals

- OEMsecrets transitions from request-based to subscription pricing
- Monthly OEMsecrets bill exceeds a defined threshold
- OEMsecrets data quality for Future Electronics MPNs is below 80% hit rate in testing
