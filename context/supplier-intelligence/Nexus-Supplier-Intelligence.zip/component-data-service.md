---
title: "Project — Component Data Service"
date: 2026-04-09
type: project
status: planned
phase: design
owner: ""
target_platform: "[[projects/organizational-ai-platform]]"
depends_on:
  - "[[decisions/replace-nexar-octopart-with-multi-distributor-api-platform]]"
  - "[[decisions/m3-is-system-of-record-for-part-master]]"
related_strategy:
  - "[[strategy/component-data-independence-from-paid-aggregators]]"
related_risks:
  - "[[risks/distributor-api-rate-limit-dependency]]"
  - "[[risks/oemsecrets-pricing-opacity]]"
related_vendors:
  - "[[vendors/digikey]]"
  - "[[vendors/mouser]]"
  - "[[vendors/arrow-electronics]]"
  - "[[vendors/element14-farnell-newark]]"
  - "[[vendors/oemsecrets]]"
tags:
  - project
  - component-data
  - bom
  - ecn
  - api
  - ai-platform
  - infrastructure
---

## Purpose

Build the **Component Data Service** — the foundational data infrastructure layer of the organizational AI platform that replaces Nexar/Octopart as the source of live component pricing and BOM validation data.

This service is a prerequisite for both BOM analysis and ECN management features on the new platform. It must be designed once and reused by both.

## Problem statement

The legacy production system uses Nexar/Octopart as an aggregator over six distributor data sources (DigiKey, Octopart, Future Electronics, Mouser, Element14, Arrow). Nexar forced a paid tier upgrade for required features, and the Octopart API v4 has been deprecated. This is structurally a solved problem — all six sources have free direct APIs. The legacy system will not be retrofitted given its 2–3 month replacement timeline.

## Scope

### In scope
- Multi-distributor API integration: DigiKey, Mouser, Arrow, Element14/Farnell/Newark
- OEMsecrets as fallback aggregator (covers Future Electronics and 135+ additional distributors)
- Response normalization to a unified internal JSON schema
- Redis-based pricing cache with TTL strategy tuned to usage pattern
- BOM batch validation: accepts a list of MPNs, returns enriched pricing + availability per line
- M3 integration: reads approved supplier list and MPN from M3 part master per IPN lookup
- Component search: MPN → distributor results with pricing breaks, stock, lead time, datasheet URL

### Out of scope (v1)
- Lifecycle / EOL management (no free API equivalent — deferred)
- RoHS / REACH compliance data (deferred — evaluate SiliconExpert or X-Refs for v2)
- InvenTree deployment (optional — evaluate if M3 UI is insufficient for engineers)
- Historical pricing trend analysis (deferred)
- Counterfeit detection / authorized distributor enforcement beyond approved supplier list in M3

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    AI Platform consumers                     │
│         BOM Analysis Module    ECN Management Module        │
└──────────────────────┬──────────────────────────────────────┘
                       │ REST / event
┌──────────────────────▼──────────────────────────────────────┐
│                 Component Data Service                       │
│                                                             │
│  ┌─────────────┐  ┌──────────────────┐  ┌───────────────┐  │
│  │Pricing Cache│  │  BOM Validator   │  │  Normalizer   │  │
│  │(Redis)      │  │  batch · dedup   │  │  unified JSON │  │
│  │TTL: see §   │  │  MPN-level       │  │  per source   │  │
│  └─────────────┘  └──────────────────┘  └───────────────┘  │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                  Fallback Router                      │  │
│  │  DigiKey → Mouser → Arrow → Element14 → OEMsecrets   │  │
│  └──────────────────────────────────────────────────────┘  │
└───────┬─────────────────────────────────────────┬──────────┘
        │ free APIs (keyed)                        │ read
        ▼                                          ▼
  Distributor APIs                          M3 Part Master
  DigiKey v4, Mouser,                      IPN → MPN
  Arrow, Element14,                        Approved suppliers
  OEMsecrets (fallback)                    Internal cost standards
```

## Distributor API registration checklist

Before design phase begins, register developer accounts and obtain API credentials for all sources. These are free — complete before writing any integration code.

- [ ] **DigiKey** — https://developer.digikey.com/ — OAuth2 client credentials, register app, obtain Client ID + Secret
- [ ] **Mouser** — https://www.mouser.com/api-hub/ — API key registration, note per-minute and per-day rate limits
- [ ] **Arrow** — https://developers.arrow.com/api/ — Login + API key, review Pricing & Availability API docs
- [ ] **Element14 / Farnell / Newark** — https://partner.element14.com/ — Partner Portal registration, API key, confirm "courtesy usage allowance" terms and ongoing usage options
- [ ] **OEMsecrets** — https://www.oemsecrets.com/api — Contact to request API access, confirm pricing model before committing as production fallback
- [ ] **Nexar (Octopart)** — Request temporary quota increase to cover legacy system through platform replacement window

## Unified JSON schema (target)

Every distributor response must be normalized to this shape before reaching any consumer:

```json
{
  "mpn": "LM358N",
  "manufacturer": "Texas Instruments",
  "description": "Op-Amp, 2-channel, DIP-8",
  "source": "digikey",
  "retrieved_at": "2026-04-09T10:00:00Z",
  "cache_hit": false,
  "datasheet_url": "https://...",
  "lifecycle_status": null,
  "offers": [
    {
      "distributor": "DigiKey",
      "distributor_sku": "296-1395-5-ND",
      "stock": 12500,
      "moq": 1,
      "lead_time_weeks": null,
      "currency": "USD",
      "price_breaks": [
        { "quantity": 1,    "unit_price": 0.67 },
        { "quantity": 10,   "unit_price": 0.54 },
        { "quantity": 100,  "unit_price": 0.41 },
        { "quantity": 1000, "unit_price": 0.31 }
      ]
    }
  ]
}
```

Fields that a distributor does not provide must be `null` — never omitted. This allows consumers to handle missing data consistently.

## Cache TTL strategy

TTL design is deferred pending answers to two questions:

1. Is pricing used for real-time quoting (engineers pricing before PO) or BOM cost estimation (ballpark acceptable)?
2. Does the company buy via spot / blanket PO / mix?

**Starting point for design phase discussion:**

| Data type | Proposed TTL | Rationale |
|-----------|-------------|-----------|
| Standard pricing (non-contract) | 24h | Prices stable intraday; distributor feeds update daily |
| Stock / availability | 4–8h | Stock depletes faster than price changes |
| Datasheet URL | 7 days | Rarely changes; high cache efficiency |
| Lifecycle / EOL status | 24h | Low-frequency changes; not yet in scope for v1 |
| Contract / account pricing | Do not cache | Must always be live; account-specific |

Cache key: `{distributor}:{mpn}:{currency}:{locale}` — locale matters because Element14 returns region-specific pricing.

Cache invalidation trigger: any BOM submitted with `force_refresh=true` bypasses cache for all MPNs in that BOM.

**Finalize TTL strategy before Redis implementation.** See [[strategy/component-pricing-cache-ttl-strategy]] (to be created).

## BOM validation flow

```
Input: [ { "mpn": "LM358N", "qty": 100 }, ... ]

1. Deduplicate MPNs across BOM lines
2. Check Redis cache per MPN — return cached offer if hit
3. For cache misses: fan out to distributor APIs in fallback order
4. Normalize each response to unified JSON schema
5. Populate cache with result + TTL
6. Enrich with M3 data: match IPN, flag non-approved suppliers
7. Return enriched BOM with per-line pricing, stock, and M3 approval status
```

Batch size limit: 500 MPNs per BOM submission in v1. Above this, split into chunks and process sequentially with a progress callback.

## M3 integration points

| M3 entity | Field | Used for |
|-----------|-------|----------|
| MITMAS (Item master) | MMITNO (IPN), MMTX40 (description) | MPN lookup anchor |
| MIPUR (Purchase item) | PDSUNO (supplier), PDITNO (item) | Approved supplier validation |
| MIPRICE (Purchase price) | PPPUPR (purchase price) | Internal cost standard comparison |

M3 integration is read-only in v1. Write-back (e.g. updating standard cost from market data) is deferred to a later phase.

## Risks

### Rate limit dependency on distributor APIs
**Risk:** Mouser and Element14 impose per-minute/per-day rate limits. Unexpected BOM batch volume could exhaust quota.
**Mitigation:** Redis cache as primary defense. Circuit breaker per distributor — if rate limited, skip to next in fallback order. Monitor rate limit headers on every response.
See [[risks/distributor-api-rate-limit-dependency]].

### OEMsecrets pricing opacity
**Risk:** OEMsecrets API pricing model is "request-based" and not publicly documented. Could become expensive at scale.
**Mitigation:** Confirm pricing before production commitment. Use only as fallback (cache miss + primary API miss). Set a monthly call budget cap with alerting.
See [[risks/oemsecrets-pricing-opacity]].

### Distributor API schema drift
**Risk:** Distributor APIs change response schema without versioned notice, breaking the normalizer silently.
**Mitigation:** Schema validation on every response using a contract test suite. Alert on unexpected fields or missing required fields. Do not pass raw distributor responses to consumers.

### Element14 courtesy allowance ambiguity
**Risk:** Element14 API terms reference a "courtesy usage allowance" for getting started, with ongoing usage requiring separate discussion. Production use at 1k–50k calls/month may require a commercial arrangement.
**Mitigation:** Contact Element14 partner team before production deployment to confirm terms.

## Development phases

### Phase 0 — API registration and exploration (before design freeze)
- Register all distributor developer accounts
- Run exploratory queries against each API with a sample BOM of 20–30 MPNs
- Document actual response schemas (not just docs — docs lag reality)
- Confirm OEMsecrets pricing and Element14 usage terms
- Decision: InvenTree yes/no

### Phase 1 — Core service (MVP)
- DigiKey + Mouser integration (highest coverage, best documented)
- Normalizer for those two sources
- Redis cache with initial TTL values
- BOM batch endpoint (up to 50 MPNs)
- M3 read integration (IPN → MPN → approved supplier lookup)
- Basic fallback: DigiKey → Mouser → error

### Phase 2 — Full distributor coverage
- Arrow + Element14 integration
- OEMsecrets as fallback aggregator
- Normalizer extended to all five sources
- BOM batch limit raised to 500 MPNs
- Cache TTL strategy finalized and tuned against real traffic

### Phase 3 — Platform integration
- BOM analysis module consumes Component Data Service
- ECN management module consumes Component Data Service (alternate part pricing, availability impact)
- M3 write-back evaluation (standard cost update from market data)
- Lifecycle / EOL data source evaluation (SiliconExpert, X-Refs, or similar)

## Open questions

- [ ] What is the actual rate limit on the Mouser API (per minute / per day)? Confirm from API hub after registration.
- [ ] Does Element14 require a commercial arrangement for >X calls/month? Confirm with partner team.
- [ ] What is OEMsecrets' pricing model for API access? Must be confirmed before Phase 2 commitment.
- [ ] Is InvenTree needed, or does M3 + the Component Data Service cover the BOM management use case adequately for engineers?
- [ ] What TTL values are appropriate given actual quoting vs. estimation usage patterns? Requires stakeholder input from procurement/engineering.
- [ ] Should the service expose a webhook/event for "price changed by >N%" to trigger ECN review? (Platform design question)
- [ ] Future Electronics: is OEMsecrets coverage sufficient, or do we need a direct commercial API arrangement?

## Definition of done (Phase 1)

- [ ] DigiKey and Mouser APIs integrated and returning normalized responses
- [ ] Redis cache operational with configurable TTL per data type
- [ ] BOM batch endpoint accepting up to 50 MPNs and returning enriched results
- [ ] M3 approved supplier flag present in every offer response
- [ ] Schema validation tests passing for both distributor normalizers
- [ ] Rate limit handling: circuit breaker per distributor, fallback routing operational
- [ ] API registration complete for all five sources (even if not integrated yet)
- [ ] Cache hit rate >60% under simulated repeat-BOM workload
- [ ] No Nexar/Octopart dependency anywhere in the codebase
